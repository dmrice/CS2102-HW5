import java.util.GregorianCalendar;
import java.util.LinkedList;

public class WeatherMonitor{
private LinkedList<IDailyReport> reports;
	
	WeatherMonitor(LinkedList<IDailyReport> reports){
		this.reports = reports;
	}
	/**
	 * 
	 * @param aDate
	 * @param dateReading
	 */
	public void addDailyReport(GregorianCalendar aDate, LinkedList<Reading> dateReading) {
		LinkedList<Double> tempList = new LinkedList<Double>();
		LinkedList<Double> rainfallList = new LinkedList<Double>();
		for(Reading readings: dateReading) {
			tempList.add(readings.getTemp());
			rainfallList.add(readings.getRainfall());
		}
		DailyWeatherReport nextReport = new DailyWeatherReport(aDate, tempList, rainfallList);
		reports.add(nextReport);
	}
	/**
	 * 
	 * @param aMonth
	 * @param aYear
	 * @return double for averageTempForMonth
	 */
	public double averageTempForMonth(int aMonth, int aYear) {
		double averageTemp = 0.0;
		LinkedList<Double> DayAvg = new LinkedList<Double>();
		double avgSum = 0.0;
		for(IDailyReport report: reports) {
			double eachDayAvg = 0.0;
			double sum = 0.0;
			if(report.getaDate().get(GregorianCalendar.MONTH) == aMonth && report.getaDate().get(GregorianCalendar.YEAR) == aYear) {
				for(double temp : report.getTemp()) {
					sum += temp;
				}
				eachDayAvg = sum/ report.getTemp().size();
				DayAvg.add(eachDayAvg);
			}
		}
		for(double eachDayAvg : DayAvg) {
			avgSum +=  eachDayAvg;
		}
		averageTemp = avgSum / DayAvg.size();
		return averageTemp;
	}
	/**
	 * 
	 * @param aMonth
	 * @param aYear
	 * @return sum for totalRainFallForMonth
	 */
	public double totalRainfallForMonth(int aMonth, int aYear) {
		double sum = 0.0;
		for(IDailyReport report: reports) {
			if (report.getaDate().get(GregorianCalendar.MONTH) == aMonth && report.getaDate().get(GregorianCalendar.YEAR) == aYear){
				for(double rainfall : report.getRainfall()) {
					sum += rainfall;
				}
			}
		}
		return sum;
	}
}
