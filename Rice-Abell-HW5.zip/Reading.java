
public class Reading {
	private Time timeReading;
	private double temp, rainfall;
	
	Reading(Time times, double temp, double rainfall){
		this.timeReading = times;
		this.temp = temp;
		this.rainfall = rainfall;
	}
	
	//functions for variables
	/**
	 * 
	 * @return the time
	 */
	public Time getTime() {
		Time timeReturn = timeReading;
		return timeReturn;
	}
	/**
	 * 
	 * @return the temperature
	 */
	public double getTemp() {
		double tempReturn = temp;
		return tempReturn;
	}
	
	/**
	 * 
	 * @return the rainfall
	 */
	double getRainfall() {
		double rainfallReturn = rainfall;
		return rainfallReturn;
	}

}
