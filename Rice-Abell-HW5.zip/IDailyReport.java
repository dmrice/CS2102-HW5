import java.util.GregorianCalendar;
import java.util.LinkedList;

public interface IDailyReport {
	LinkedList<Double> getTemp();
	LinkedList<Double> getRainfall();
	GregorianCalendar getaDate();
}
