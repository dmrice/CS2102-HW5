import java.util.GregorianCalendar;
import java.util.LinkedList;

public class DailyWeatherReport implements IDailyReport {
	
	private GregorianCalendar date;
	private LinkedList<Double> temp = new LinkedList<Double>();
	private LinkedList<Double> rainfall = new LinkedList<Double>();
	
	DailyWeatherReport(GregorianCalendar date, LinkedList<Double> temp, LinkedList<Double> rainfall){
		this.date = date;
		this.temp = temp;
		this.rainfall = rainfall;
		
	}
	//functions for variables
	
	/**
	 * 
	 * @return the dateReturn
	 */
	public GregorianCalendar getaDate() {
		GregorianCalendar dateReturn = date;
		return dateReturn;
	}
	/**
	 * 
	 * @return tempReturn
	 */
	public LinkedList<Double> getTemp() {
		LinkedList<Double> tempReturn = temp;
		return tempReturn;
	}
	/**
	 * @return rainfallReturn
	 */
	public LinkedList<Double> getRainfall() {
		LinkedList<Double> rainfallReturn = new LinkedList<Double>();
		rainfallReturn = this.rainfall;
		return rainfallReturn;
	}
	/**
	 * 
	 * @param month
	 * @param year
	 * @return true or false if the date entered matches the date you are checking
	 */
	boolean dateCheck(int month, int year) {
		return (this.date.get(GregorianCalendar.MONTH) ==month && this.date.get(GregorianCalendar.YEAR) == year);
	}


}
