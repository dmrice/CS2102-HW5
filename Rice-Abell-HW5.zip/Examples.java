import static org.junit.Assert.*;

import java.util.GregorianCalendar;
import java.util.LinkedList;

import org.junit.Test;
/**
 * 
 * @author Deanna Rice and Phillip Abell
 *
 */

public class Examples {
	GregorianCalendar addedDate = new GregorianCalendar(2017, 1, 1);
	LinkedList<Reading> newReadings;
	
	Time t1 = new Time(5, 12);
	Time t2 = new Time(2, 59);
	Time t3 = new Time(3, 20);
	Reading r1 = new Reading(t1, 42, 4.7);
	Reading r2 = new Reading(t2, 75, 1.2);
	Reading r3 = new Reading(t3, 21, 2.0);

	LinkedList<IDailyReport> weatherReports;


	WeatherMonitor WR;

	public Examples() {
		///1
		LinkedList<Double> rainfall1 = new LinkedList<Double>();
		rainfall1.add(4.0);
		rainfall1.add(1.2);
		rainfall1.add(12.0);
		LinkedList<Double> temperature1 = new LinkedList<Double>();
		temperature1.add(72.0);
		temperature1.add(60.8);
		temperature1.add(32.3);		
		DailyWeatherReport report1 = new DailyWeatherReport(new GregorianCalendar(2018, 3, 22), temperature1, rainfall1);

		///2
		LinkedList<Double> rainfall2 = new LinkedList<Double>();
		rainfall2.add(1.4);
		rainfall2.add(0.5);
		rainfall2.add(6.0);
		LinkedList<Double> temperature2 = new LinkedList<Double>();
		temperature2.add(95.0);
		temperature2.add(50.8);
		temperature2.add(12.2);
		DailyWeatherReport report2 = new DailyWeatherReport(new GregorianCalendar(2018, 11, 13), temperature2, rainfall2);

		///3
		LinkedList<Double> rainfall3 = new LinkedList<Double>();
		rainfall3.add(2.4);
		rainfall3.add(1.5);
		rainfall3.add(5.0);
		LinkedList<Double> temperature3 = new LinkedList<Double>();
		temperature3.add(22.0);
		temperature3.add(12.8);
		temperature3.add(1.2);
		DailyWeatherReport report3 = new DailyWeatherReport(new GregorianCalendar(2018, 10, 18), temperature3, rainfall3);

		//end for trio
		weatherReports = new LinkedList<IDailyReport>();	
		weatherReports.add(report1);
		weatherReports.add(report2);
		weatherReports.add(report3);

		newReadings = new LinkedList<Reading>();
		newReadings.add(r1);
		newReadings.add(r2);
		newReadings.add(r3);

		WR = new WeatherMonitor(weatherReports);

	}

	@Test
	public void getHour() {
		assertEquals(t1.getHour(), 5);
	}

	@Test
	public void getMinute() {
		assertEquals(t2.getMinute(), 59);
	}

	@Test
	public void getTime() {
		assertEquals(r1.getTime(), t1);
	}

	@Test
	public void getTemp() {
		assertEquals(r2.getTemp(), 75, 1.2);
	}

	@Test
	public void getRainfall() {
		assertEquals(r3.getRainfall(), 2.0, 21);
	}

	//report 1
	@Test
	public void testAverageTempForMonthMarch() {
		assertEquals(WR.averageTempForMonth(3, 2018), 55.03, 0.1);
	}

	@Test
	public void testTotalRainfallForMonthMarch() {
		assertEquals(WR.totalRainfallForMonth(3, 2018), 17.2, 0.1);
	}

	//report 2
	@Test
	public void testAverageTempForMonthNovember() {
		assertEquals(WR.averageTempForMonth(11, 2018), 52.66, 0.1);
	}

	@Test
	public void testTotalRainfallForMonthNovember() {
		assertEquals(WR.totalRainfallForMonth(11, 2018), 7.9, 0.1);
	}

	//report 3
	@Test
	public void testAverageTempForMonthOctober() {
		assertEquals(WR.averageTempForMonth(10, 2018), 12.0, 0.1);
	}

	@Test
	public void testTotalRainfallForMonthOctober() {
		assertEquals(WR.totalRainfallForMonth(10, 2018), 8.9, 0.1);
	}
	
	@Test
	public void addD() {
		WR.addDailyReport(addedDate, newReadings);
		assertEquals(WR.averageTempForMonth(1 ,2017), 46.0, 0.1);
	}
}

