
public class Time {
	private int hour;
	private int minute;
	
	Time(int hour, int minute){
		this.hour = hour;
		this.minute = minute;
	}
	//collect function for variable
	
	/**
	 * 
	 * @return the hour
	 */
	public int getHour() {
		return this.hour;
	}
	/**
	 * 
	 * @return the minute
	 */
	public int getMinute() {
		return this.minute;
	}

}
